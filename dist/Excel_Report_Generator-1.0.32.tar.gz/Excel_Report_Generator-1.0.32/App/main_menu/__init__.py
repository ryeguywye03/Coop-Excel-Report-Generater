from .main_menu import MainMenuUI # Import the main UI class

# Define what will be accessible when importing sr_counter
__all__ = ['MainMenuUI']
